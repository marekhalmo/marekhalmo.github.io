$(function() {

  var $main = $("main");
  window.mySparticles = new Sparticles($main.get(0));

});
