const presets = [
  [
    "@babel/preset-env",
    {
      targets: {
        ie: "9",
      },
    },
  ],
];

module.exports = { presets };
